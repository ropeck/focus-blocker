/*!
 * JavaScript for Injection
 *
 * @author Tetsuwo OISHI
 */

chrome.extension.sendRequest({ title: document.title, url: location });
